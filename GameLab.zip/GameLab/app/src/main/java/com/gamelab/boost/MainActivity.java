package com.gamelab.boost;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ_SHIZUKU = 1;
    private static final int BG = 0xFF0B0B0F, CARD = 0xFF16161D, ACCENT = 0xFF00C853,
            WARN = 0xFFFFB300, DIM = 0xFF8A8A96;

    private SharedPreferences sp;
    private TextView status, log;
    private Button bPerm, bApply, bLaunch, bReset;
    private RadioGroup rg;
    private Switch swDens, swBlur, swAnim, swDnd, swBatt, swKill, swGame;
    private EditText etGame, etKill;

    private final Shizuku.OnBinderReceivedListener onBinder = () -> ui(this::refresh);
    private final Shizuku.OnBinderDeadListener onDead = () -> ui(this::refresh);
    private final Shizuku.OnRequestPermissionResultListener onPerm = (c, r) -> ui(this::refresh);
    private final BroadcastReceiver battReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { refresh(); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("gl", MODE_PRIVATE);
        buildUi();
        Shizuku.addBinderReceivedListenerSticky(onBinder);
        Shizuku.addBinderDeadListener(onDead);
        Shizuku.addRequestPermissionResultListener(onPerm);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 0);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(battReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(battReceiver, f);
        refresh();
    }

    @Override
    protected void onPause() {
        try { unregisterReceiver(battReceiver); } catch (Exception ignored) {}
        saveUi();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder);
        Shizuku.removeBinderDeadListener(onDead);
        Shizuku.removeRequestPermissionResultListener(onPerm);
        super.onDestroy();
    }

    // ------------------------------------------------------------ actions
    private void ui(Runnable r) { runOnUiThread(r); }

    private void boost(final boolean launch) {
        saveUi();
        final Boost.Opts o = readOpts();
        final Context app = getApplicationContext();
        log("Applying…");
        ShizukuHelper.with(s -> {
            String msg = Boost.apply(app, s, o, launch);
            Notifier.show(app);
            ui(() -> { log(msg); refresh(); });
        }, e -> ui(() -> log("Error: " + e)));
    }

    private void reset() {
        final Context app = getApplicationContext();
        log("Restoring…");
        ShizukuHelper.with(s -> {
            String msg = Boost.restore(app, s);
            Notifier.clear(app);
            ui(() -> { log(msg); refresh(); });
        }, e -> ui(() -> log("Error: " + e)));
    }

    private void onPermission() {
        if (!ShizukuHelper.running()) {
            Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (i != null) startActivity(i); else log("Shizuku is not installed.");
        } else {
            Shizuku.requestPermission(REQ_SHIZUKU);
        }
    }

    // ------------------------------------------------------------ state
    private Boost.Opts readOpts() {
        Boost.Opts o = new Boost.Opts();
        int idx = rg.getCheckedRadioButtonId() - 1000;
        o.width = (idx >= 0 && idx < Boost.WIDTHS.length) ? Boost.WIDTHS[idx] : 0;
        o.density = swDens.isChecked();
        o.blur = swBlur.isChecked();
        o.anim = swAnim.isChecked();
        o.dnd = swDnd.isChecked();
        o.battery = swBatt.isChecked();
        o.kill = swKill.isChecked();
        o.gameMode = swGame.isChecked();
        o.game = etGame.getText().toString().trim();
        o.killList = etKill.getText().toString();
        return o;
    }

    private void saveUi() {
        int idx = rg.getCheckedRadioButtonId() - 1000;
        sp.edit()
                .putInt("o.res", Math.max(idx, 0))
                .putBoolean("o.dens", swDens.isChecked())
                .putBoolean("o.blur", swBlur.isChecked())
                .putBoolean("o.anim", swAnim.isChecked())
                .putBoolean("o.dnd", swDnd.isChecked())
                .putBoolean("o.batt", swBatt.isChecked())
                .putBoolean("o.kill", swKill.isChecked())
                .putBoolean("o.game", swGame.isChecked())
                .putString("o.pkg", etGame.getText().toString().trim())
                .putString("o.killlist", etKill.getText().toString())
                .apply();
    }

    private void refresh() {
        boolean run = ShizukuHelper.running();
        boolean ok = ShizukuHelper.granted();
        int uid = ShizukuHelper.serverUid();
        boolean active = sp.getBoolean("active", false);

        String bat = "—";
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b != null) {
            float t = b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
            int l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            bat = String.format(Locale.US, "%.1f°C · %d%%", t, l);
        }

        status.setText(
                dot("Shizuku running", run)
              + dot("Permission granted", ok)
              + dot("ADB binder active", uid == 2000 || uid == 0)
              + "Mode:    " + (uid == 0 ? "root" : uid == 2000 ? "ADB (shell)" : "—") + "\n"
              + "Battery: " + bat + "\n"
              + "Session: " + (active ? "BOOSTED — reset when done" : "normal"));

        bPerm.setVisibility(ok ? View.GONE : View.VISIBLE);
        bPerm.setText(run ? "Grant Shizuku permission" : "Open Shizuku");
        bApply.setEnabled(ok);
        bLaunch.setEnabled(ok);
        bReset.setEnabled(ok);
        bReset.setBackgroundColor(active ? WARN : CARD);
        bReset.setTextColor(active ? Color.BLACK : Color.WHITE);
    }

    private static String dot(String label, boolean v) { return (v ? "● " : "○ ") + label + "\n"; }
    private void log(String s) { log.setText(s); }

    // ------------------------------------------------------------ UI
    private void buildUi() {
        int p = dp(20);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, dp(40), p, p);
        sv.addView(root);

        root.addView(text("GameLab Boost", 24, Color.WHITE, true));
        root.addView(text("Tweak → play → reset. Everything is restored to what it was before.", 13, DIM, false));

        status = text("", 14, Color.WHITE, false);
        status.setTypeface(Typeface.MONOSPACE);
        status.setBackgroundColor(CARD);
        status.setPadding(p, p, p, p);
        root.addView(status, lp(dp(16)));

        bPerm = button("Grant Shizuku permission", CARD);
        bPerm.setOnClickListener(v -> onPermission());
        root.addView(bPerm, lp(dp(12)));

        root.addView(text("RESOLUTION", 12, DIM, true), lp(dp(20)));
        rg = new RadioGroup(this);
        String[] names = {"Native (no change)", "720p", "540p", "480p"};
        for (int i = 0; i < names.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(names[i]);
            rb.setTextColor(Color.WHITE);
            rg.addView(rb);
        }
        rg.check(1000 + sp.getInt("o.res", 1));
        root.addView(rg);
        swDens = sw(root, "Scale density with resolution (keeps UI size)", "dens", true);

        root.addView(text("TWEAKS", 12, DIM, true), lp(dp(16)));
        swBlur = sw(root, "Disable window blur", "blur", true);
        swAnim = sw(root, "Turn off system animations", "anim", true);
        swDnd  = sw(root, "Do Not Disturb (priority only)", "dnd", false);
        swBatt = sw(root, "Disable battery saver & adaptive battery", "batt", true);
        swGame = sw(root, "Game Mode: performance (if supported)", "game", true);
        swKill = sw(root, "Free RAM: kill background apps", "kill", true);

        root.addView(text("GAME PACKAGE", 12, DIM, true), lp(dp(16)));
        etGame = edit(sp.getString("o.pkg", Boost.DEF_GAME), false);
        root.addView(etGame, lp(dp(4)));

        root.addView(text("APPS TO FORCE-STOP (one per line)", 12, DIM, true), lp(dp(16)));
        etKill = edit(sp.getString("o.killlist", Boost.DEF_KILL), true);
        root.addView(etKill, lp(dp(4)));

        bLaunch = button("Boost & Launch Game", ACCENT);
        bLaunch.setTextColor(Color.BLACK);
        bLaunch.setOnClickListener(v -> boost(true));
        root.addView(bLaunch, lp(dp(20)));

        bApply = button("Apply Boost (don't launch)", CARD);
        bApply.setOnClickListener(v -> boost(false));
        root.addView(bApply, lp(dp(8)));

        bReset = button("Reset to Normal", CARD);
        bReset.setOnClickListener(v -> reset());
        root.addView(bReset, lp(dp(8)));

        log = text("", 12, DIM, false);
        root.addView(log, lp(dp(16)));

        setContentView(sv);
    }

    private Switch sw(LinearLayout root, String label, String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setChecked(sp.getBoolean("o." + key, def));
        s.setPadding(0, dp(8), 0, dp(8));
        root.addView(s);
        return s;
    }

    private EditText edit(String value, boolean multi) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setBackgroundColor(CARD);
        e.setTextSize(13);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setTypeface(Typeface.MONOSPACE);
        int type = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        if (multi) { type |= InputType.TYPE_TEXT_FLAG_MULTI_LINE; e.setMinLines(4); e.setGravity(Gravity.TOP); }
        e.setInputType(type);
        return e;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String s, int bg) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(bg);
        return b;
    }

    private LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        l.topMargin = top;
        return l;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
