package com.gamelab.boost;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

final class Notifier {
    private static final int ID = 1;
    private static final String CH = "session";

    static void show(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "Game session", NotificationManager.IMPORTANCE_LOW));
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(c, 1,
                new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), flags);
        PendingIntent reset = PendingIntent.getBroadcast(c, 0, new Intent(c, RestoreReceiver.class), flags);
        Notification n = new Notification.Builder(c, CH)
                .setSmallIcon(android.R.drawable.ic_menu_revert)
                .setContentTitle("GameLab boost active")
                .setContentText("Reset to restore your normal settings")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(0, "Reset to Normal", reset).build())
                .setOngoing(true)
                .build();
        nm.notify(ID, n);
    }

    static void clear(Context c) {
        c.getSystemService(NotificationManager.class).cancel(ID);
    }
}
