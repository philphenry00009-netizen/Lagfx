package com.gamelab.boost;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Snapshot -> apply -> restore engine.
 * Before the first change of a session the ORIGINAL values are saved to disk,
 * so "Reset to Normal" puts back exactly what the phone had (even after a reboot).
 */
final class Boost {

    static final String DEF_GAME = "com.activision.callofduty.shooter";
    static final String DEF_KILL =
            "com.facebook.katana\ncom.facebook.orca\ncom.instagram.android\n"
          + "com.zhiliaoapp.musically\ncom.snapchat.android\ncom.google.android.youtube\n"
          + "com.android.chrome\ncom.netflix.mediaclient";
    static final int[] WIDTHS = {0, 720, 540, 480};

    private static final Pattern PKG  = Pattern.compile("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+");
    private static final Pattern SIZE = Pattern.compile("(\\d+)x(\\d+)");

    static final class Opts {
        int width;
        boolean density, blur, anim, dnd, battery, kill, gameMode;
        String game = DEF_GAME;
        String killList = DEF_KILL;
    }

    private static final String SNAP =
            "echo \"OVSIZE=$(wm size | sed -n 's/^Override size: *//p')\";"
          + "echo \"PHSIZE=$(wm size | sed -n 's/^Physical size: *//p')\";"
          + "echo \"OVDEN=$(wm density | sed -n 's/^Override density: *//p')\";"
          + "echo \"PHDEN=$(wm density | sed -n 's/^Physical density: *//p')\";"
          + "echo \"blur=$(settings get global disable_window_blurs)\";"
          + "echo \"wanim=$(settings get global window_animation_scale)\";"
          + "echo \"tanim=$(settings get global transition_animation_scale)\";"
          + "echo \"danim=$(settings get global animator_duration_scale)\";"
          + "echo \"zen=$(settings get global zen_mode)\";"
          + "echo \"lowp=$(settings get global low_power)\";"
          + "echo \"adapt=$(settings get global adaptive_battery_management_enabled)\"";

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("gl", Context.MODE_PRIVATE);
    }

    private static String g(SharedPreferences sp, String key) {
        return sp.getString("snap." + key, "");
    }

    // ------------------------------------------------------------ APPLY
    static String apply(Context c, IShellService s, Opts o, boolean launch) throws Exception {
        if (!PKG.matcher(o.game).matches()) throw new IllegalArgumentException("Invalid game package name");
        SharedPreferences sp = prefs(c);

        // 1. Snapshot originals once per session
        if (!sp.getBoolean("active", false)) {
            SharedPreferences.Editor e = sp.edit();
            for (String line : s.exec(SNAP).split("\n")) {
                int i = line.indexOf('=');
                if (i > 0) e.putString("snap." + line.substring(0, i).trim(), line.substring(i + 1).trim());
            }
            e.commit();
        }

        Set<String> applied = new LinkedHashSet<>();
        String prev = sp.getString("applied", "");
        if (!prev.isEmpty()) applied.addAll(Arrays.asList(prev.split(",")));

        StringBuilder cmd = new StringBuilder();

        // 2. Resolution (+ matching density so the UI keeps its size)
        if (o.width > 0) {
            Matcher m = SIZE.matcher(g(sp, "PHSIZE"));
            if (m.find()) {
                int pw = Integer.parseInt(m.group(1)), ph = Integer.parseInt(m.group(2));
                if (pw > o.width) {
                    int nh = Math.round(ph * (float) o.width / pw);
                    nh -= nh % 2;
                    cmd.append("wm size ").append(o.width).append('x').append(nh).append("; ");
                    applied.add("size");
                    if (o.density) {
                        try {
                            int pd = Integer.parseInt(g(sp, "PHDEN"));
                            int nd = Math.round(pd * (float) o.width / pw);
                            if (nd > 0) { cmd.append("wm density ").append(nd).append("; "); applied.add("den"); }
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }
        }

        // 3. System tweaks
        if (o.blur) { cmd.append("settings put global disable_window_blurs 1; "); applied.add("blur"); }
        if (o.anim) {
            cmd.append("settings put global window_animation_scale 0; ")
               .append("settings put global transition_animation_scale 0; ")
               .append("settings put global animator_duration_scale 0; ");
            applied.add("anim");
        }
        if (o.dnd) { cmd.append("cmd notification set_dnd priority; "); applied.add("dnd"); }
        if (o.battery) {
            cmd.append("settings put global low_power 0; ")
               .append("settings put global adaptive_battery_management_enabled 0; ");
            applied.add("batt");
        }
        if (o.gameMode) {
            // Android 12 and 13+ use different syntax; the one that doesn't apply just fails silently.
            cmd.append("cmd game mode performance ").append(o.game).append(" 2>/dev/null; ")
               .append("cmd game set --mode performance ").append(o.game).append(" 2>/dev/null; ");
            applied.add("game");
        }

        // 4. Free RAM
        if (o.kill) {
            cmd.append("am kill-all; ");
            for (String p : o.killList.split("\\s+")) {
                if (PKG.matcher(p).matches() && !p.equals(o.game)) cmd.append("am force-stop ").append(p).append("; ");
            }
        }

        // 5. Launch
        if (launch) {
            cmd.append("monkey -p ").append(o.game)
               .append(" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1");
        }

        s.exec(cmd.toString());

        sp.edit().putBoolean("active", true)
                .putString("applied", join(applied))
                .putString("game", o.game)
                .commit();
        return "Session active. Applied: " + (applied.isEmpty() ? "nothing" : join(applied));
    }

    // ---------------------------------------------------------- RESTORE
    static String restore(Context c, IShellService s) throws Exception {
        SharedPreferences sp = prefs(c);
        String ap = sp.getString("applied", "");
        StringBuilder cmd = new StringBuilder();

        if (ap.isEmpty()) {
            cmd.append("wm size reset; wm density reset; ");   // safe fallback
        } else {
            Set<String> a = new HashSet<>(Arrays.asList(ap.split(",")));
            if (a.contains("size")) cmd.append(wm("size", g(sp, "OVSIZE"), "\\d+x\\d+"));
            if (a.contains("den"))  cmd.append(wm("density", g(sp, "OVDEN"), "\\d+"));
            if (a.contains("blur")) cmd.append(key("disable_window_blurs", g(sp, "blur")));
            if (a.contains("anim")) {
                cmd.append(key("window_animation_scale", g(sp, "wanim")))
                   .append(key("transition_animation_scale", g(sp, "tanim")))
                   .append(key("animator_duration_scale", g(sp, "danim")));
            }
            if (a.contains("dnd")) {
                int z = 0;
                try { z = Integer.parseInt(g(sp, "zen")); } catch (NumberFormatException ignored) {}
                String mode = z == 1 ? "priority" : z == 2 ? "none" : z == 3 ? "alarms" : "off";
                cmd.append("cmd notification set_dnd ").append(mode).append("; ");
            }
            if (a.contains("batt")) {
                cmd.append(key("low_power", g(sp, "lowp")))
                   .append(key("adaptive_battery_management_enabled", g(sp, "adapt")));
            }
            if (a.contains("game")) {
                String game = sp.getString("game", "");
                if (PKG.matcher(game).matches()) {
                    cmd.append("cmd game mode standard ").append(game).append(" 2>/dev/null; ")
                       .append("cmd game reset ").append(game).append(" 2>/dev/null; ");
                }
            }
        }

        s.exec(cmd.toString());
        sp.edit().putBoolean("active", false).putString("applied", "").commit();
        return "Restored to normal.";
    }

    // ---------------------------------------------------------- helpers
    private static String wm(String kind, String original, String regex) {
        return original.matches(regex)
                ? "wm " + kind + " " + original + "; "
                : "wm " + kind + " reset; ";
    }

    private static String key(String name, String v) {
        if (v.isEmpty() || v.equals("null") || !v.matches("[0-9A-Za-z._-]+"))
            return "settings delete global " + name + "; ";
        return "settings put global " + name + " " + v + "; ";
    }

    private static String join(Set<String> set) {
        StringBuilder sb = new StringBuilder();
        for (String x : set) { if (sb.length() > 0) sb.append(','); sb.append(x); }
        return sb.toString();
    }
}
